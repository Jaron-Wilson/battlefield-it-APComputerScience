package Projects;

import java.util.Scanner;


public class RFOS {

    public static void main(String[] args) {

        Scanner scnr = new Scanner(System.in);
        // JARON WILSON


        // Define menu items and their prices

        String[] menuItems = {

            "Chicken Curry", "Shrimp Curry", "Naan", "Chai", "Crabs",

            "Lamb Biriyani", "Veg Biriyani", "Gobi Manchurian", "Chana Masala", "Kheer"

        };

        double[] menuPrices = {10.69, 14.25, 3.59, 2.45, 7.24, 15.59, 11.27, 10.35, 9.45, 4.99};


        // Initialize variables for calculations

        double totalPrice = 0.0;

        double tax = 0.0;

        double tip = 0.0;


        // Display the menu

        System.out.println("Mr. K’s Indian Food Menu");

        for (int i = 0; i < menuItems.length; i++) {

            System.out.println((i + 1) + " " + menuItems[i] + " $" + menuPrices[i]);

        }


        // Ask the user how many dishes they want to order

        System.out.print("How many different dishes would you like to order today? ");

        int numDishes = scnr.nextInt();


        // Input and calculate order details

        for (int i = 0; i < numDishes; i++) {

            System.out.print("Enter dish " + (i + 1) + " [1-10] ");

            int dishNumber = scnr.nextInt();

            System.out.print("How many servings of dish " + dishNumber + " would you like to order? ");

            int servings = scnr.nextInt();


            // Calculate the cost of the selected dish

            double dishCost = menuPrices[dishNumber - 1] * servings;

            totalPrice += dishCost;

        }


        // Calculate tax

        System.out.print("Enter the tax %: ");

        double taxRate = scnr.nextDouble();

        tax = (taxRate / 100) * totalPrice;


        // Ask if the user wants to leave a tip

        System.out.print("Do you want to add tip? ['y' - yes or 'n' - no] ");

        char tipChoice = scnr.next().charAt(0);


        if (tipChoice == 'y' || tipChoice == 'Y') {

            System.out.print("Enter tip % [0-100]: ");

            double tipPercentage = scnr.nextDouble();

            tip = (tipPercentage / 100) * totalPrice;

        }


        // Calculate the total amount

        double totalAmount = totalPrice + tax + tip;


        // Display the order summary

        System.out.printf("Price: %.2f%n", totalPrice);

        System.out.printf("Tax (%.1f%%): %.2f%n", taxRate, tax);

        if (tip > 0.0) {

            System.out.printf("Tip (%.1f%%): %.2f%n", (tip / totalPrice) * 100, tip);

        }

        System.out.println("----------------");

        System.out.printf("Total Amount: $%.2f%n", totalAmount);


        System.out.println("Your order has been placed and will be delivered soon!");

    }

}





